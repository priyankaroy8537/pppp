package com.proy.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.proy.entity.StudentMarks;
import com.proy.repository.StudentMarksRepository;

@RestController
@RequestMapping("/marks")
public class StudentMarksController {

    @Autowired
    private StudentMarksRepository studentMarksRepository;

    @GetMapping("/{id}")
    public StudentMarks getStudentMarksById(@PathVariable Long id) {
        return studentMarksRepository.findById(id).orElse(null);
    }

    @PostMapping
    public StudentMarks createStudentMarks(@RequestBody StudentMarks studentMarks) {
        return studentMarksRepository.save(studentMarks);
    }
}
