package com.proy.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.proy.entity.StudentMarks;

public interface StudentMarksRepository extends JpaRepository<StudentMarks, Long> {
}

