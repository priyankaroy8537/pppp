package com.proy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Studentmarksms4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
